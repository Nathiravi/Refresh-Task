import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HotelbookingComponent } from './hotelbooking/hotelbooking.component';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,HotelbookingComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'TravelApp';
  lastchild : string = "float: right;";
  usericon : string ="../assets/User.jpg";
  logouticon: string = "../assets/logout.jpg";
  align : string ="margin-top: -5px;";
  formshow : boolean=false;
  statusshow : boolean=true;
  showForm(){
    this.formshow=!this.formshow;
    this.statusshow=!this.statusshow;
  }
}
