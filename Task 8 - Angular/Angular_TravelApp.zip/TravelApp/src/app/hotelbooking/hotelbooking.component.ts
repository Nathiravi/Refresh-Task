import { Component} from '@angular/core';
import { FormsModule, NgForm} from '@angular/forms';
import {NgForOf } from '@angular/common';
import { CurrencyPipe } from '@angular/common';


@Component({
  selector: 'app-hotelbooking',
  standalone: true,
  imports: [NgForOf,CurrencyPipe,FormsModule],
  templateUrl: './hotelbooking.component.html',
  styleUrl: './hotelbooking.component.css'
})
export class HotelbookingComponent {
numbers:number[]=[1,2,3,4,5,6,7,8,9,10];

cost:number=0;

Hoteldetails:{Type:string,Roomcount:number,Personcount:number,Childrencount:number,Restaurant:string}=
{
  Type:'',Roomcount:0,Personcount:0,Childrencount:0,Restaurant:''
};

CalculateCost(form:NgForm){
  if(this.Hoteldetails.Type="Room"){
    if(this.Hoteldetails.Restaurant="Yes"){
      this.cost=(this.Hoteldetails.Roomcount*850)+(this.Hoteldetails.Personcount*400)+(this.Hoteldetails.Childrencount*300);
    }
    else{
      this.cost=(this.Hoteldetails.Roomcount*850)+(this.Hoteldetails.Personcount*400)+(this.Hoteldetails.Childrencount*170);
    }
  }
  if(this.Hoteldetails.Type="Suite"){
    if(this.Hoteldetails.Restaurant="Yes"){
      this.cost=(this.Hoteldetails.Roomcount*1200)+(this.Hoteldetails.Personcount*400)+(this.Hoteldetails.Childrencount*300);
    }
    else{
      this.cost=(this.Hoteldetails.Roomcount*1200)+(this.Hoteldetails.Personcount*400)+(this.Hoteldetails.Childrencount*170);
    }
  }
}
}
