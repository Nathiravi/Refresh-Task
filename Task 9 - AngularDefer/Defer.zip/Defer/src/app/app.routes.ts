import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { HotelbookingComponent } from './hotelbooking/hotelbooking.component';

export const routes: Routes = [{
    path:'Booking',
    component:HotelbookingComponent
}];
